# Copyright (c) Kyutai, all rights reserved.
# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.
"""
Models for the compression model Moshi,
"""

# flake8: noqa
from .compression import (
    CompressionModel,
    MimiModel,
)
from .lm import LMModel, LMGen
from .loaders import get_mimi, get_moshi_lm
from .gesture_codec import GestureMimiCodec
from .gesture_lm import GestureLMGen, GTemporalDepthModel3
from .gesture_lm_c2f import GestureLMC2FGen, GTemporalDepthModel3C2F
from .gesture_lm_offline import (
    GestureLMOfflineGen,
    GTemporalDepthModel3Offline,
)
from .gesture_lm_condition_c import (
    GTemporalDepthModel3ConditionC,
    forward_condition_c_teacher_view,
)
from .gesture_lm_future_gesture import (
    GTemporalDepthModel3FutureGesture,
    GTemporalDepthModel3FutureGestureFullCondition,
)
from .gesture_lm_regret import (
    forward_q0_regret_kl,
    is_temporal_q0_state_key,
    retain_temporal_q0_only,
)
from .gesture_lm_shared_regret import (
    dense_regret_kl,
    forward_dense_future_gesture_teacher_view,
    forward_linguistic_teacher_view,
    forward_teacher_view,
    relaxed_temporal_cross_attention,
    relaxed_temporal_self_attention,
)
from .gesture_lm_reset_future import (
    ResetFutureBoundary,
    ResetSuffixEncoding,
    build_reset_future_teacher_inputs,
    build_reset_future_teacher_inputs_from_codes,
    encode_intact_motion,
    encode_reset_suffix,
)
from .rvq_depth_regularization import (
    StochasticRVQEncoding,
    encode_stochastic_rvq,
)
